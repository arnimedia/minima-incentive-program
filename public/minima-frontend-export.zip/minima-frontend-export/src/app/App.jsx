import React, { useEffect } from 'react'
import { useRoutes } from 'react-router-dom'
import AppRoutes from '../routes/app.routes'
import { useDispatch, useSelector } from 'react-redux'
import { loggedInTest } from '../account/account.slice.js'
import Spinner from './spinner/Spinner'
import ReactGA from "react-ga4";

ReactGA.initialize("G-DDSV5HNX4J");
ReactGA.send("pageview");

function App() {
    const dispatch = useDispatch()

    // Login check with back end
    useEffect(() => {
        dispatch(loggedInTest(`/api/test`))
    }, [dispatch])

    const routes = useRoutes(AppRoutes)

    return (
        <>
            <div className='mn-wrap'>{routes}</div>
            <Spinner></Spinner>
        </>
    )
}

export { App }
