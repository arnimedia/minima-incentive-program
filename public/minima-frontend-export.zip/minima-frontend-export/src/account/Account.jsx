// import React, { useEffect } from 'react';

// function Account({ history, match, authenticated, ...rest }) {
//     const { path } = match;

//     useEffect(() => {
//         // redirect to home if already logged in
//         if (authenticated) {
//             history.push('/');
//         }
//     }, []);

//     return (
//         <div className="container">

//         </div>
//     );
// }

// export { Account };
