import React from "react";
import classNames from "classnames";
import Logo from "./Logo";
import NavMain from '../_components/NavMain'

const Header = () => {

  const headerClass = classNames({
    "mn-header": true,
    "mn-header-fixed": true,
    "bg-white": true,
  });
  return (
    <>
    <div className={headerClass}>
      <div className="container-lg wide-xl">
        <div className="mn-header-wrap">
          <div className="mn-header-brand">
            <Logo />
          </div>
            <NavMain />
        </div>
      </div>
    </div>
    <div className="mn-header-line">
        <div className="container-lg wide-xl">
          The Minima Incentive Program
        </div>
    </div>
    </>
  );
};
export default Header;
